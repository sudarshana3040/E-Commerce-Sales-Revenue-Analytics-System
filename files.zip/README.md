# 📊 E-Commerce Sales & Revenue Analytics System

> **Industry-level Data Analytics project** built with Python, Pandas, NumPy, SQL, and interactive dashboards.  
> Suitable for **Data Analyst** and **Business Analyst** resume portfolios.

---

## 🗂️ Project Structure

```
ecommerce_analytics/
├── data/
│   ├── raw_ecommerce_data.csv       # Generated synthetic dataset (15,175 rows)
│   └── cleaned_ecommerce_data.csv   # Cleaned & feature-engineered dataset
├── sql/
│   └── ecommerce_queries.sql        # 20+ production-ready SQL queries
├── visualizations/
│   ├── 01_monthly_sales_profit_trend.png
│   ├── 02_yearly_comparison.png
│   ├── 03_category_performance.png
│   ├── 04_regional_analysis.png
│   ├── 05_top_customers.png
│   ├── 06_discount_impact.png
│   ├── 07_shipping_analysis.png
│   ├── 08_correlation_heatmap.png
│   ├── 09_top_products.png
│   ├── 10_customer_retention.png
│   ├── 11_seasonal_heatmap.png
│   └── 12_profit_margin_distribution.png
├── dashboard/
│   └── ecommerce_dashboard.html     # Interactive HTML/Chart.js dashboard
├── reports/
│   ├── kpis.json                    # Machine-readable KPI summary
│   └── business_insights.txt        # Full business insights report
├── generate_data.py                 # Synthetic dataset generator
├── analysis.py                      # Full analytics pipeline
└── README.md
```

---

## 🎯 Project Overview

This end-to-end analytics system analyzes **4 years of e-commerce data (2020–2023)** spanning:

| Metric | Value |
|--------|-------|
| Total Revenue | $43.6M |
| Total Profit | $5.4M |
| Profit Margin | 12.5% |
| Total Orders | 5,000 |
| Unique Customers | 791 |
| Avg Order Value | $8,721 |

---

## 🛠️ Tech Stack

| Layer | Tools |
|-------|-------|
| **Data Generation** | Python, NumPy, Random |
| **Data Cleaning** | Pandas, NumPy, SciPy |
| **EDA & Analysis** | Pandas, NumPy, SciPy (stats) |
| **Visualizations** | Matplotlib, Seaborn |
| **SQL Analytics** | SQLite / PostgreSQL |
| **Dashboard** | HTML, CSS, Chart.js |

---

## 🚀 Quick Start

### 1. Clone & Install Dependencies
```bash
git clone https://github.com/yourusername/ecommerce-analytics.git
cd ecommerce-analytics

pip install pandas numpy matplotlib seaborn scipy scikit-learn openpyxl
```

### 2. Generate Dataset
```bash
python generate_data.py
# Output: data/raw_ecommerce_data.csv (15,175 rows)
```

### 3. Run Full Analysis Pipeline
```bash
python analysis.py
# Outputs:
#   data/cleaned_ecommerce_data.csv
#   visualizations/*.png (12 charts)
#   reports/business_insights.txt
#   reports/kpis.json
```

### 4. Open Interactive Dashboard
```bash
# Open in browser
open dashboard/ecommerce_dashboard.html
# or: python -m http.server 8080 (then visit localhost:8080/dashboard/)
```

### 5. Run SQL Queries
```bash
# Load into SQLite
sqlite3 ecommerce.db <<EOF
.mode csv
.import data/cleaned_ecommerce_data.csv ecommerce_orders
EOF

sqlite3 ecommerce.db < sql/ecommerce_queries.sql
```

---

## 📋 Analysis Modules

### 1. Data Cleaning & Preprocessing
- **Missing values**: Imputed `ship_date` using median delay per ship mode; `customer_name` filled with "Unknown Customer"
- **Duplicates**: 411 duplicate rows detected and removed (2.7%)
- **Outliers**: IQR method applied on `sales`; 962 statistical outliers flagged
- **Feature engineering**: `order_year`, `order_month`, `order_quarter`, `ship_delay`, `profit_margin_pct`, `year_month`
- **Type standardization**: Dates parsed, numerics clipped to valid ranges

### 2. Exploratory Data Analysis
| Analysis | Key Finding |
|----------|-------------|
| Monthly trend | Q4 peaks consistently (~35% above Q1) |
| Category | Technology = 59% revenue, 70% profit |
| Regional | South leads margin (12.8%); West trails (12.0%) |
| Top customer | 10 customers = ~18% of total revenue |
| Discount impact | R² confirms discounts >20% → negative margins |
| Ship mode | Standard Class = 55% volume; Same Day = 6% |

### 3. SQL Query Library
20+ queries organized in 8 sections:
1. Revenue & Profit KPIs
2. Customer Analysis (Top 10, Cohort, RFM Scoring)
3. Product & Category Analysis
4. Regional Drill-down
5. Monthly & Quarterly Trends
6. Discount & Shipping Analysis
7. Average Order Value
8. Advanced Window Functions

### 4. Visualizations (12 Charts)
| # | Chart | Type |
|---|-------|------|
| 01 | Monthly Sales & Profit Trend | Line + Bar |
| 02 | Year-over-Year Comparison | Grouped Bar |
| 03 | Category & Sub-Category Performance | Pie + Bar |
| 04 | Regional Analysis | Horizontal Bar |
| 05 | Top Customers + Segment Share | Bar + Pie |
| 06 | Discount Impact | Bar + Scatter |
| 07 | Shipping Mode Analysis | Bar |
| 08 | Correlation Heatmap | Heatmap |
| 09 | Top Products by Revenue/Profit | Horizontal Bar |
| 10 | Customer Retention & Frequency | Pie + Histogram |
| 11 | Seasonal Sales Heatmap | Heatmap |
| 12 | Profit Margin Distribution | Histogram + Boxplot |

---

## 💡 Key Business Insights

### 1. Technology is the Profit Engine
- Technology: 59% of revenue → **70% of profit** ($3.8M)
- Office Supplies: only 10% of revenue → **17% of profit** (high margin)
- **Action**: Increase Technology SKU mix; push Office Supplies bundles

### 2. Furniture Margin Alert
- Furniture margin: **4.9%** — 2.5× lower than other categories
- Deep discounts on Furniture erode already thin margins
- **Action**: Negotiate supplier COGS; cap Furniture discounts at 15%

### 3. Discount Ceiling: 20%
- 0% discount → **18.4% avg margin**
- 31–50% discount → **-6.8% avg margin** (selling at a loss)
- **Action**: Hard-cap automated discounts at 20%; use loyalty points instead

### 4. Q4 Seasonality is Predictable
- Q4 revenue is consistently **+35% above Q1**
- October–December: highest-traffic months every year
- **Action**: Pre-load inventory by September; ramp marketing spend in October

### 5. Customer Retention is Strong
- Only 1.3% of customers purchased just once (excellent retention)
- Opportunity: increase repeat purchase rate in Corporate segment
- **Action**: Assign dedicated account managers to top 50 Corporate customers

### 6. Regional Balance with Optimization Opportunity
- All regions: 12.0–12.8% margin (healthy band)
- West trails by 0.8pp — investigate logistics / pricing
- **Action**: Apply South pricing playbook to West region

---

## 📊 Dashboard Features

The interactive HTML dashboard includes:
- **6 KPI Cards**: Revenue, Profit, Margin, Orders, Customers, AOV
- **Monthly Trend**: Revenue + Profit line chart with gradient fills
- **Category Donut**: Revenue share by category
- **Regional Charts**: Revenue vs Profit grouped bar + Margin horizontal bar
- **Ship Mode**: Order distribution donut chart
- **Quarterly Grouped Bar**: 4-year comparison by quarter
- **Discount Impact**: Margin by discount band with positive/negative coloring
- **Product Progress Bars**: Top 8 by profit
- **Sub-category Horizontal Bar**: Color-coded by parent category
- **Segment Table**: Revenue, profit, margin, share for each segment
- **Insights Panel**: 8 actionable business insights
- **Filters**: Year, Region, Category, Segment, Ship Mode

---

## 📁 Dataset Schema

| Column | Type | Description |
|--------|------|-------------|
| `order_id` | String | Unique order identifier |
| `order_date` | Date | Date order was placed |
| `ship_date` | Date | Date order was shipped |
| `ship_mode` | String | Standard / Second / First / Same Day |
| `customer_id` | String | Unique customer identifier |
| `customer_name` | String | Full name |
| `segment` | String | Consumer / Corporate / Home Office |
| `city` / `state` / `region` | String | Geographic hierarchy |
| `product_id` / `product_name` | String | Product identifiers |
| `category` / `sub_category` | String | Product classification |
| `quantity` | Integer | Units ordered |
| `unit_price` | Float | Price per unit ($) |
| `discount` | Float | Discount rate (0–1) |
| `sales` | Float | Total revenue for line item |
| `profit` | Float | Net profit for line item |
| `ship_delay` | Integer | Days from order to ship |
| `profit_margin_pct` | Float | Profit as % of sales |

---

## 🎓 Skills Demonstrated

- **Python**: Pandas, NumPy, Matplotlib, Seaborn, SciPy
- **SQL**: Aggregations, CTEs, Window functions, RANK, NTILE, LAG
- **Data Cleaning**: Missing value imputation, deduplication, outlier detection (IQR)
- **EDA**: Trend analysis, correlation, distribution analysis
- **Business Intelligence**: KPI definition, insight generation, actionable recommendations
- **Data Visualization**: 12 publication-quality charts across 6 chart types
- **Dashboard Development**: Interactive filters, multiple chart types, professional layout

---

## 📄 License

MIT License — free to use, modify, and distribute for personal or commercial projects.

---

## 👤 Author

**Data Analytics Portfolio Project**  
Built with Python · Pandas · NumPy · SQL · Chart.js

*This project uses a synthetically generated dataset that realistically simulates a B2C e-commerce business operating across the United States.*
