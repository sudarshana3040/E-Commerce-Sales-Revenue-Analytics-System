"""
E-Commerce Dataset Generator
Generates a realistic synthetic dataset mimicking the Superstore dataset
"""

import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta

np.random.seed(42)
random.seed(42)

# ─── Reference Data ────────────────────────────────────────────────────────────

CATEGORIES = {
    "Technology": {
        "sub": ["Phones", "Accessories", "Copiers", "Machines"],
        "base_price": (50, 2000),
        "margin": (0.05, 0.35),
    },
    "Furniture": {
        "sub": ["Chairs", "Tables", "Bookcases", "Furnishings"],
        "base_price": (30, 1500),
        "margin": (-0.05, 0.25),
    },
    "Office Supplies": {
        "sub": ["Binders", "Paper", "Storage", "Labels", "Envelopes", "Fasteners", "Art", "Supplies"],
        "base_price": (2, 300),
        "margin": (0.10, 0.45),
    },
}

PRODUCTS = {
    "Phones":       ["Apple iPhone 14", "Samsung Galaxy S22", "Google Pixel 7", "Motorola Edge 30", "OnePlus 10T"],
    "Accessories":  ["Logitech Mouse", "Dell Keyboard", "Belkin USB Hub", "Anker Charger", "Sony Headphones"],
    "Copiers":      ["Canon imageCLASS", "HP LaserJet", "Epson WorkForce", "Brother HL-L2350DW"],
    "Machines":     ["Brother Label Maker", "Fellowes Shredder", "Swingline Stapler Pro", "Acco Punch"],
    "Chairs":       ["Hon Task Chair", "Flash Furniture Chair", "IKEA MARKUS", "Steelcase Leap"],
    "Tables":       ["Realspace Magellan Desk", "Sauder Beginnings", "Bush Cabot Desk", "Techni Mobili"],
    "Bookcases":    ["Sauder 5-Shelf Bookcase", "Threshold 3-Shelf", "Bush Furniture Bookcase", "ClosetMaid"],
    "Furnishings":  ["Eldon Wave Desk", "O'Sullivan Printer Stand", "Luxo Lamp", "Quartet Easel"],
    "Binders":      ["Avery Heavy Duty Binder", "Wilson Jones Binder", "Cardinal EasyOpen", "Avery Durable"],
    "Paper":        ["Hammermill Paper", "HP Office Paper", "Georgia-Pacific Spectrum", "Staples Paper"],
    "Storage":      ["Storex Portable File Box", "Iris Weathertight Tote", "Sterilite Storage", "Fellowes Storage"],
    "Labels":       ["Avery Easy Peel Labels", "Avery Mailing Labels", "Dymo LabelWriter"],
    "Envelopes":    ["Columbian Clasp Envelope", "Universal Catalog Envelope", "Jiffy Padded Mailer"],
    "Fasteners":    ["Advantus Rubber Bands", "Alliance Rubber Bands", "ACCO Binder Clips"],
    "Art":          ["Sanford Prismacolor Markers", "Fiskars Scissors", "Quartet Dry-Erase Markers"],
    "Supplies":     ["Sanford Super Stick", "Dixon Ticonderoga Pencils", "BIC Round Stic Pens"],
}

REGIONS = {
    "West":    ["California", "Washington", "Oregon", "Nevada", "Arizona", "Colorado", "Utah"],
    "East":    ["New York", "Pennsylvania", "Virginia", "Florida", "Georgia", "North Carolina"],
    "Central": ["Texas", "Illinois", "Ohio", "Michigan", "Minnesota", "Missouri", "Wisconsin"],
    "South":   ["Tennessee", "Louisiana", "Alabama", "Mississippi", "Arkansas", "Kentucky"],
}

CITIES_BY_STATE = {
    "California": ["Los Angeles", "San Francisco", "San Diego", "San Jose"],
    "Washington": ["Seattle", "Spokane", "Tacoma"],
    "Oregon": ["Portland", "Eugene", "Salem"],
    "Nevada": ["Las Vegas", "Reno", "Henderson"],
    "Arizona": ["Phoenix", "Tucson", "Scottsdale"],
    "Colorado": ["Denver", "Colorado Springs", "Aurora"],
    "Utah": ["Salt Lake City", "Provo", "Ogden"],
    "New York": ["New York City", "Buffalo", "Rochester"],
    "Pennsylvania": ["Philadelphia", "Pittsburgh", "Allentown"],
    "Virginia": ["Virginia Beach", "Richmond", "Norfolk"],
    "Florida": ["Miami", "Orlando", "Tampa", "Jacksonville"],
    "Georgia": ["Atlanta", "Savannah", "Augusta"],
    "North Carolina": ["Charlotte", "Raleigh", "Greensboro"],
    "Texas": ["Houston", "Dallas", "Austin", "San Antonio"],
    "Illinois": ["Chicago", "Aurora", "Rockford"],
    "Ohio": ["Columbus", "Cleveland", "Cincinnati"],
    "Michigan": ["Detroit", "Grand Rapids", "Warren"],
    "Minnesota": ["Minneapolis", "Saint Paul", "Duluth"],
    "Missouri": ["Kansas City", "Saint Louis", "Springfield"],
    "Wisconsin": ["Milwaukee", "Madison", "Green Bay"],
    "Tennessee": ["Nashville", "Memphis", "Knoxville"],
    "Louisiana": ["New Orleans", "Baton Rouge", "Shreveport"],
    "Alabama": ["Birmingham", "Montgomery", "Huntsville"],
    "Mississippi": ["Jackson", "Gulfport", "Biloxi"],
    "Arkansas": ["Little Rock", "Fort Smith", "Fayetteville"],
    "Kentucky": ["Louisville", "Lexington", "Bowling Green"],
}

SHIP_MODES = ["Standard Class", "Second Class", "First Class", "Same Day"]
SHIP_WEIGHTS = [0.55, 0.22, 0.17, 0.06]

SEGMENTS = ["Consumer", "Corporate", "Home Office"]
SEG_WEIGHTS = [0.52, 0.30, 0.18]

FIRST_NAMES = ["James","Mary","John","Patricia","Robert","Jennifer","Michael","Linda",
               "William","Barbara","David","Elizabeth","Richard","Susan","Joseph","Jessica",
               "Thomas","Sarah","Charles","Karen","Christopher","Lisa","Daniel","Nancy",
               "Matthew","Betty","Anthony","Margaret","Mark","Sandra","Donald","Ashley",
               "Steven","Dorothy","Paul","Kimberly","Andrew","Emily","Kenneth","Donna"]
LAST_NAMES = ["Smith","Johnson","Williams","Brown","Jones","Garcia","Miller","Davis",
              "Wilson","Anderson","Taylor","Thomas","Hernandez","Moore","Martin","Jackson",
              "Thompson","White","Lopez","Lee","Gonzalez","Harris","Clark","Lewis","Robinson",
              "Walker","Perez","Hall","Young","Allen","Sanchez","Wright","King","Scott","Green"]


def random_date(start, end):
    delta = end - start
    return start + timedelta(days=random.randint(0, delta.days))


def generate_dataset(n_customers=793, n_orders=5000):
    start_date = datetime(2020, 1, 1)
    end_date   = datetime(2023, 12, 31)

    # ── Customers ──────────────────────────────────────────────────────────────
    customers = []
    for i in range(n_customers):
        cid = f"CUS-{i+1:04d}"
        name = f"{random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}"
        seg  = random.choices(SEGMENTS, SEG_WEIGHTS)[0]
        region = random.choice(list(REGIONS.keys()))
        state  = random.choice(REGIONS[region])
        city   = random.choice(CITIES_BY_STATE.get(state, [state + " City"]))
        customers.append({"customer_id": cid, "customer_name": name,
                          "segment": seg, "city": city, "state": state, "region": region})

    cust_df = pd.DataFrame(customers)

    # ── Orders ─────────────────────────────────────────────────────────────────
    rows = []
    order_counter = 1

    for _ in range(n_orders):
        customer = cust_df.sample(1).iloc[0]
        order_date = random_date(start_date, end_date)
        ship_mode  = random.choices(SHIP_MODES, SHIP_WEIGHTS)[0]
        ship_delay = {"Same Day": 0, "First Class": 2, "Second Class": 4, "Standard Class": 6}
        ship_date  = order_date + timedelta(days=ship_delay[ship_mode] + random.randint(0, 2))

        order_id = f"ORD-{order_counter:05d}"
        order_counter += 1

        n_items = random.randint(1, 5)
        for _ in range(n_items):
            category = random.choices(list(CATEGORIES.keys()), [0.35, 0.25, 0.40])[0]
            cat_cfg  = CATEGORIES[category]
            sub      = random.choice(cat_cfg["sub"])
            product_name = random.choice(PRODUCTS[sub])
            product_id   = f"PRD-{abs(hash(product_name)) % 9000 + 1000}"

            qty      = random.randint(1, 10)
            price    = round(random.uniform(*cat_cfg["base_price"]), 2)
            discount = random.choices([0, 0.1, 0.2, 0.3, 0.4, 0.5],
                                       [0.45, 0.20, 0.15, 0.10, 0.06, 0.04])[0]
            sales    = round(price * qty * (1 - discount), 2)
            margin   = random.uniform(*cat_cfg["margin"])
            # higher discounts erode margin
            margin  -= discount * 0.5
            profit   = round(sales * margin, 2)

            rows.append({
                "order_id":      order_id,
                "order_date":    order_date.strftime("%Y-%m-%d"),
                "ship_date":     ship_date.strftime("%Y-%m-%d"),
                "ship_mode":     ship_mode,
                "customer_id":   customer["customer_id"],
                "customer_name": customer["customer_name"],
                "segment":       customer["segment"],
                "city":          customer["city"],
                "state":         customer["state"],
                "region":        customer["region"],
                "product_id":    product_id,
                "product_name":  product_name,
                "category":      category,
                "sub_category":  sub,
                "quantity":      qty,
                "unit_price":    price,
                "discount":      discount,
                "sales":         sales,
                "profit":        profit,
                "row_id":        len(rows) + 1,
            })

    df = pd.DataFrame(rows)

    # ── Inject realistic noise ─────────────────────────────────────────────────
    # missing values (~1.5%)
    for col in ["ship_date", "customer_name"]:
        mask = np.random.rand(len(df)) < 0.008
        df.loc[mask, col] = np.nan

    # duplicates (~0.5%)
    dup_idx = np.random.choice(df.index, size=int(len(df) * 0.005), replace=False)
    df = pd.concat([df, df.loc[dup_idx]], ignore_index=True)

    # outlier sales
    outlier_idx = np.random.choice(df.index, size=10, replace=False)
    df.loc[outlier_idx, "sales"] = df.loc[outlier_idx, "sales"] * random.uniform(8, 15)

    df = df.sample(frac=1, random_state=42).reset_index(drop=True)
    return df


if __name__ == "__main__":
    df = generate_dataset()
    df.to_csv("/home/claude/ecommerce_analytics/data/raw_ecommerce_data.csv", index=False)
    print(f"Generated {len(df)} rows, {df['order_id'].nunique()} orders, {df['customer_id'].nunique()} customers")
    print(df.head(3).to_string())
