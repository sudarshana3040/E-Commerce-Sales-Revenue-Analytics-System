-- ============================================================================
--  E-COMMERCE SALES & REVENUE ANALYTICS — SQL QUERY LIBRARY
--  Compatible with: PostgreSQL, MySQL 8+, SQLite, SQL Server
--  Dataset: ecommerce_orders (cleaned)
-- ============================================================================

-- ────────────────────────────────────────────────────────────────────────────
-- TABLE SCHEMA (reference)
-- ────────────────────────────────────────────────────────────────────────────
/*
CREATE TABLE ecommerce_orders (
    row_id          INTEGER PRIMARY KEY,
    order_id        VARCHAR(20),
    order_date      DATE,
    ship_date       DATE,
    ship_mode       VARCHAR(30),
    customer_id     VARCHAR(15),
    customer_name   VARCHAR(100),
    segment         VARCHAR(30),
    city            VARCHAR(80),
    state           VARCHAR(80),
    region          VARCHAR(20),
    product_id      VARCHAR(15),
    product_name    VARCHAR(150),
    category        VARCHAR(50),
    sub_category    VARCHAR(50),
    quantity        INTEGER,
    unit_price      DECIMAL(10,2),
    discount        DECIMAL(5,2),
    sales           DECIMAL(12,2),
    profit          DECIMAL(12,2),
    order_year      INTEGER,
    order_month     INTEGER,
    order_quarter   INTEGER,
    ship_delay      INTEGER,
    profit_margin_pct DECIMAL(8,2)
);
*/


-- ============================================================================
-- SECTION 1 — REVENUE & PROFIT KPIs
-- ============================================================================

-- 1.1 Overall Business KPIs
SELECT
    COUNT(DISTINCT order_id)                                        AS total_orders,
    COUNT(DISTINCT customer_id)                                     AS total_customers,
    ROUND(SUM(sales), 2)                                            AS total_revenue,
    ROUND(SUM(profit), 2)                                           AS total_profit,
    ROUND(SUM(profit) / NULLIF(SUM(sales), 0) * 100, 2)            AS profit_margin_pct,
    ROUND(SUM(sales) / COUNT(DISTINCT order_id), 2)                 AS avg_order_value,
    ROUND(SUM(quantity) * 1.0 / COUNT(DISTINCT order_id), 2)        AS avg_units_per_order
FROM ecommerce_orders;


-- 1.2 Annual Revenue & Growth
WITH yearly AS (
    SELECT
        order_year,
        ROUND(SUM(sales), 2)   AS revenue,
        ROUND(SUM(profit), 2)  AS profit,
        COUNT(DISTINCT order_id) AS orders
    FROM ecommerce_orders
    GROUP BY order_year
)
SELECT
    order_year,
    revenue,
    profit,
    orders,
    ROUND(profit / NULLIF(revenue, 0) * 100, 2)          AS margin_pct,
    ROUND(
        (revenue - LAG(revenue) OVER (ORDER BY order_year))
        / NULLIF(LAG(revenue) OVER (ORDER BY order_year), 0) * 100, 2
    )                                                     AS yoy_growth_pct
FROM yearly
ORDER BY order_year;


-- ============================================================================
-- SECTION 2 — CUSTOMER ANALYSIS
-- ============================================================================

-- 2.1 Top 10 Customers by Revenue
SELECT
    customer_id,
    customer_name,
    segment,
    region,
    COUNT(DISTINCT order_id)            AS total_orders,
    SUM(quantity)                       AS units_purchased,
    ROUND(SUM(sales), 2)               AS total_revenue,
    ROUND(SUM(profit), 2)              AS total_profit,
    ROUND(SUM(profit)/NULLIF(SUM(sales),0)*100, 2) AS margin_pct
FROM ecommerce_orders
GROUP BY customer_id, customer_name, segment, region
ORDER BY total_revenue DESC
LIMIT 10;


-- 2.2 Repeat Customer Analysis (Cohort)
WITH customer_orders AS (
    SELECT
        customer_id,
        customer_name,
        segment,
        COUNT(DISTINCT order_id) AS order_count,
        MIN(order_date)          AS first_order,
        MAX(order_date)          AS last_order,
        ROUND(SUM(sales), 2)    AS lifetime_value
    FROM ecommerce_orders
    GROUP BY customer_id, customer_name, segment
)
SELECT
    CASE
        WHEN order_count = 1  THEN '1-time buyer'
        WHEN order_count <= 5 THEN 'Repeat (2-5 orders)'
        ELSE 'Loyal (6+ orders)'
    END                         AS customer_type,
    COUNT(*)                    AS customer_count,
    ROUND(AVG(lifetime_value),2) AS avg_lifetime_value,
    ROUND(AVG(order_count),1)   AS avg_orders
FROM customer_orders
GROUP BY customer_type
ORDER BY avg_lifetime_value DESC;


-- 2.3 Customer Segmentation by Revenue
SELECT
    segment,
    COUNT(DISTINCT customer_id)  AS customers,
    COUNT(DISTINCT order_id)     AS orders,
    ROUND(SUM(sales), 2)        AS revenue,
    ROUND(SUM(profit), 2)       AS profit,
    ROUND(SUM(sales)/COUNT(DISTINCT order_id),2) AS aov,
    ROUND(SUM(profit)/NULLIF(SUM(sales),0)*100,2) AS margin_pct
FROM ecommerce_orders
GROUP BY segment
ORDER BY revenue DESC;


-- 2.4 New vs Returning Customers by Year
WITH first_order AS (
    SELECT customer_id, MIN(order_year) AS first_year
    FROM ecommerce_orders
    GROUP BY customer_id
),
yearly_customers AS (
    SELECT
        o.order_year,
        o.customer_id,
        CASE WHEN f.first_year = o.order_year THEN 'New' ELSE 'Returning' END AS cust_type
    FROM ecommerce_orders o
    JOIN first_order f ON o.customer_id = f.customer_id
    GROUP BY o.order_year, o.customer_id, f.first_year
)
SELECT
    order_year,
    cust_type,
    COUNT(*) AS customers
FROM yearly_customers
GROUP BY order_year, cust_type
ORDER BY order_year, cust_type;


-- ============================================================================
-- SECTION 3 — PRODUCT & CATEGORY ANALYSIS
-- ============================================================================

-- 3.1 Category-wise Performance
SELECT
    category,
    COUNT(DISTINCT order_id)    AS orders,
    SUM(quantity)               AS units_sold,
    ROUND(SUM(sales), 2)       AS revenue,
    ROUND(SUM(profit), 2)      AS profit,
    ROUND(SUM(profit)/NULLIF(SUM(sales),0)*100, 2) AS margin_pct,
    ROUND(AVG(discount)*100, 1) AS avg_discount_pct
FROM ecommerce_orders
GROUP BY category
ORDER BY revenue DESC;


-- 3.2 Sub-category Drill-down
SELECT
    category,
    sub_category,
    COUNT(DISTINCT order_id)    AS orders,
    SUM(quantity)               AS units_sold,
    ROUND(SUM(sales), 2)       AS revenue,
    ROUND(SUM(profit), 2)      AS profit,
    ROUND(SUM(profit)/NULLIF(SUM(sales),0)*100, 2) AS margin_pct
FROM ecommerce_orders
GROUP BY category, sub_category
ORDER BY category, profit DESC;


-- 3.3 Top 10 Products by Profit
SELECT
    product_id,
    product_name,
    category,
    sub_category,
    SUM(quantity)               AS units_sold,
    ROUND(SUM(sales), 2)       AS revenue,
    ROUND(SUM(profit), 2)      AS profit,
    ROUND(SUM(profit)/NULLIF(SUM(sales),0)*100, 2) AS margin_pct
FROM ecommerce_orders
GROUP BY product_id, product_name, category, sub_category
ORDER BY profit DESC
LIMIT 10;


-- 3.4 Loss-Making Products (candidates for review/discontinue)
SELECT
    product_name,
    category,
    sub_category,
    SUM(quantity)               AS units_sold,
    ROUND(SUM(sales), 2)       AS revenue,
    ROUND(SUM(profit), 2)      AS profit,
    ROUND(AVG(discount)*100,1) AS avg_discount_pct
FROM ecommerce_orders
GROUP BY product_name, category, sub_category
HAVING SUM(profit) < 0
ORDER BY profit ASC
LIMIT 15;


-- ============================================================================
-- SECTION 4 — REGIONAL ANALYSIS
-- ============================================================================

-- 4.1 Region-wise Profit Analysis
SELECT
    region,
    COUNT(DISTINCT state)        AS states_covered,
    COUNT(DISTINCT customer_id)  AS customers,
    COUNT(DISTINCT order_id)     AS orders,
    ROUND(SUM(sales), 2)        AS revenue,
    ROUND(SUM(profit), 2)       AS profit,
    ROUND(SUM(profit)/NULLIF(SUM(sales),0)*100, 2) AS margin_pct,
    ROUND(SUM(sales)/COUNT(DISTINCT order_id), 2)   AS aov
FROM ecommerce_orders
GROUP BY region
ORDER BY profit DESC;


-- 4.2 State-level Performance (Top 15)
SELECT
    state,
    region,
    COUNT(DISTINCT customer_id)  AS customers,
    COUNT(DISTINCT order_id)     AS orders,
    ROUND(SUM(sales), 2)        AS revenue,
    ROUND(SUM(profit), 2)       AS profit,
    ROUND(SUM(profit)/NULLIF(SUM(sales),0)*100, 2) AS margin_pct
FROM ecommerce_orders
GROUP BY state, region
ORDER BY revenue DESC
LIMIT 15;


-- 4.3 Region x Category Cross-analysis
SELECT
    region,
    category,
    ROUND(SUM(sales), 2)    AS revenue,
    ROUND(SUM(profit), 2)   AS profit,
    ROUND(SUM(profit)/NULLIF(SUM(sales),0)*100, 2) AS margin_pct
FROM ecommerce_orders
GROUP BY region, category
ORDER BY region, revenue DESC;


-- ============================================================================
-- SECTION 5 — SALES TRENDS
-- ============================================================================

-- 5.1 Monthly Sales & Growth
WITH monthly AS (
    SELECT
        order_year,
        order_month,
        ROUND(SUM(sales), 2)            AS revenue,
        ROUND(SUM(profit), 2)           AS profit,
        COUNT(DISTINCT order_id)        AS orders
    FROM ecommerce_orders
    GROUP BY order_year, order_month
)
SELECT
    order_year,
    order_month,
    revenue,
    profit,
    orders,
    ROUND(
        (revenue - LAG(revenue) OVER (ORDER BY order_year, order_month))
        / NULLIF(LAG(revenue) OVER (ORDER BY order_year, order_month), 0) * 100, 2
    ) AS mom_growth_pct
FROM monthly
ORDER BY order_year, order_month;


-- 5.2 Quarterly Performance
SELECT
    order_year,
    order_quarter,
    ROUND(SUM(sales), 2)             AS revenue,
    ROUND(SUM(profit), 2)            AS profit,
    COUNT(DISTINCT order_id)         AS orders,
    ROUND(SUM(profit)/NULLIF(SUM(sales),0)*100, 2) AS margin_pct
FROM ecommerce_orders
GROUP BY order_year, order_quarter
ORDER BY order_year, order_quarter;


-- 5.3 Rolling 3-Month Average Revenue
WITH monthly_rev AS (
    SELECT
        order_year,
        order_month,
        SUM(sales) AS revenue
    FROM ecommerce_orders
    GROUP BY order_year, order_month
)
SELECT
    order_year,
    order_month,
    ROUND(revenue, 2) AS monthly_revenue,
    ROUND(AVG(revenue) OVER (
        ORDER BY order_year, order_month
        ROWS BETWEEN 2 PRECEDING AND CURRENT ROW
    ), 2) AS rolling_3m_avg
FROM monthly_rev
ORDER BY order_year, order_month;


-- ============================================================================
-- SECTION 6 — DISCOUNT & SHIPPING ANALYSIS
-- ============================================================================

-- 6.1 Discount Impact on Profitability
SELECT
    CASE
        WHEN discount = 0         THEN '0% (No discount)'
        WHEN discount <= 0.10     THEN '1-10%'
        WHEN discount <= 0.20     THEN '11-20%'
        WHEN discount <= 0.30     THEN '21-30%'
        WHEN discount <= 0.50     THEN '31-50%'
        ELSE '>50%'
    END                             AS discount_band,
    COUNT(DISTINCT order_id)        AS orders,
    ROUND(SUM(sales), 2)           AS revenue,
    ROUND(SUM(profit), 2)          AS profit,
    ROUND(AVG(profit_margin_pct),2) AS avg_margin_pct
FROM ecommerce_orders
GROUP BY discount_band
ORDER BY MIN(discount);


-- 6.2 Shipping Mode Performance
SELECT
    ship_mode,
    COUNT(DISTINCT order_id)    AS orders,
    ROUND(AVG(ship_delay), 1)  AS avg_ship_delay_days,
    ROUND(SUM(sales), 2)       AS revenue,
    ROUND(SUM(profit), 2)      AS profit,
    ROUND(SUM(profit)/NULLIF(SUM(sales),0)*100, 2) AS margin_pct
FROM ecommerce_orders
GROUP BY ship_mode
ORDER BY orders DESC;


-- ============================================================================
-- SECTION 7 — AVERAGE ORDER VALUE
-- ============================================================================

-- 7.1 Average Order Value Overall and by Segment
SELECT
    'Overall'   AS segment,
    ROUND(SUM(sales)/COUNT(DISTINCT order_id), 2) AS aov
FROM ecommerce_orders
UNION ALL
SELECT
    segment,
    ROUND(SUM(sales)/COUNT(DISTINCT order_id), 2) AS aov
FROM ecommerce_orders
GROUP BY segment
ORDER BY aov DESC;


-- 7.2 AOV Trend by Quarter
SELECT
    order_year,
    order_quarter,
    ROUND(SUM(sales)/COUNT(DISTINCT order_id), 2) AS aov,
    ROUND(SUM(quantity)*1.0/COUNT(DISTINCT order_id), 1) AS avg_units_per_order
FROM ecommerce_orders
GROUP BY order_year, order_quarter
ORDER BY order_year, order_quarter;


-- ============================================================================
-- SECTION 8 — ADVANCED / WINDOW FUNCTION QUERIES
-- ============================================================================

-- 8.1 Rank Customers within Each Region by Revenue
SELECT
    region,
    customer_name,
    ROUND(SUM(sales), 2) AS revenue,
    RANK() OVER (PARTITION BY region ORDER BY SUM(sales) DESC) AS region_rank
FROM ecommerce_orders
GROUP BY region, customer_name
QUALIFY region_rank <= 3   -- use HAVING + subquery for MySQL/SQLite
ORDER BY region, region_rank;


-- 8.2 Product Revenue Contribution % within Category
SELECT
    category,
    product_name,
    ROUND(SUM(sales), 2) AS revenue,
    ROUND(
        SUM(sales) / SUM(SUM(sales)) OVER (PARTITION BY category) * 100, 2
    ) AS pct_of_category_revenue
FROM ecommerce_orders
GROUP BY category, product_name
ORDER BY category, revenue DESC;


-- 8.3 Customer RFM Scoring (Recency, Frequency, Monetary)
WITH rfm_raw AS (
    SELECT
        customer_id,
        customer_name,
        DATEDIFF('2024-01-01', MAX(order_date))   AS recency_days,  -- days since last order
        COUNT(DISTINCT order_id)                   AS frequency,
        ROUND(SUM(sales), 2)                       AS monetary
    FROM ecommerce_orders
    GROUP BY customer_id, customer_name
),
rfm_scored AS (
    SELECT *,
        NTILE(5) OVER (ORDER BY recency_days ASC)  AS r_score,
        NTILE(5) OVER (ORDER BY frequency DESC)    AS f_score,
        NTILE(5) OVER (ORDER BY monetary DESC)     AS m_score
    FROM rfm_raw
)
SELECT
    customer_id,
    customer_name,
    recency_days,
    frequency,
    monetary,
    r_score,
    f_score,
    m_score,
    (r_score + f_score + m_score) AS rfm_total,
    CASE
        WHEN (r_score + f_score + m_score) >= 13 THEN 'Champions'
        WHEN (r_score + f_score + m_score) >= 10 THEN 'Loyal Customers'
        WHEN (r_score + f_score + m_score) >= 7  THEN 'At Risk'
        ELSE 'Lost / Inactive'
    END AS rfm_segment
FROM rfm_scored
ORDER BY rfm_total DESC;


-- ============================================================================
-- END OF SQL QUERY LIBRARY
-- ============================================================================
